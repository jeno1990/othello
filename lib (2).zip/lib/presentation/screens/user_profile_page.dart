import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:othello/controllers/user_profile_controller.dart';
import 'package:intl/intl.dart';
import 'package:country_picker/country_picker.dart';

class UserProfilePage extends GetView<UserProfileController> {
  const UserProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1E1E),
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text("User Profile", style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Obx(() => SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.person, size: 100, color: Colors.white70),
            const SizedBox(height: 20),

            _buildTextField('Username', controller.username.value,
                (val) => controller.username.value = val),
            const SizedBox(height: 20),

            _buildDropdown('Gender', controller.gender.value,
                ['Male', 'Female', 'Other'],
                (val) => controller.gender.value = val ?? ''),
            const SizedBox(height: 20),

            _buildDatePicker('Date of Birth', context, controller.birthDate.value,
                (date) => controller.birthDate.value = date),
            const SizedBox(height: 20),

            _buildTextField('City', controller.city.value,
                (val) => controller.city.value = val),
            const SizedBox(height: 20),

            _buildCountryPicker('Country', controller.country.value,
                (country) => controller.country.value = country.name),
            const SizedBox(height: 20),

            _buildTextField('Email', controller.email.value,
                (val) => controller.email.value = val,
                keyboardType: TextInputType.emailAddress),
            const SizedBox(height: 20),

            _buildTextField('Password', controller.password.value,
                (val) => controller.password.value = val,
                obscureText: controller.obscurePassword.value,
                toggleObscure: controller.obscurePassword),
            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: controller.saveProfile,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text('Save Profile', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      )),
    );
  }

  Widget _buildTextField(
    String label,
    String value,
    Function(String) onChanged, {
    bool obscureText = false,
    RxBool? toggleObscure,
    TextInputType keyboardType = TextInputType.text,
  }) {
    final controller = TextEditingController(text: value);
    controller.selection =
        TextSelection.fromPosition(TextPosition(offset: controller.text.length));

    return Obx(() => TextField(
          controller: controller,
          style: const TextStyle(color: Colors.white),
          obscureText: toggleObscure?.value ?? obscureText,
          keyboardType: keyboardType,
          onChanged: onChanged,
          decoration: InputDecoration(
            labelText: label,
            labelStyle: const TextStyle(color: Colors.white70),
            suffixIcon: toggleObscure != null
                ? IconButton(
                    icon: Icon(
                      toggleObscure.value
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Colors.white70,
                    ),
                    onPressed: () =>
                        toggleObscure.value = !toggleObscure.value,
                  )
                : null,
            enabledBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white38),
            ),
            focusedBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
            ),
          ),
        ));
  }

  Widget _buildDropdown(
    String label,
    String value,
    List<String> items,
    void Function(String?) onChanged,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 5),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.grey[850],
            borderRadius: BorderRadius.circular(8),
          ),
          child: DropdownButton<String>(
            value: value.isNotEmpty ? value : null,
            isExpanded: true,
            dropdownColor: Colors.grey[900],
            underline: const SizedBox(),
            style: const TextStyle(color: Colors.white),
            items: items
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }

  Widget _buildDatePicker(
    String label,
    BuildContext context,
    DateTime selectedDate,
    Function(DateTime) onDateSelected,
  ) {
    return GestureDetector(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: selectedDate,
          firstDate: DateTime(1900),
          lastDate: DateTime.now(),
          builder: (context, child) => Theme(
            data: ThemeData.dark(),
            child: child!,
          ),
        );
        if (picked != null) onDateSelected(picked);
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              DateFormat('dd/MM/yyyy').format(selectedDate),
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCountryPicker(
    String label,
    String value,
    Function(Country) onSelect,
  ) {
    return GestureDetector(
      onTap: () {
        showCountryPicker(
          context: Get.context!,
          showPhoneCode: false,
          countryListTheme: CountryListThemeData(
            backgroundColor: Colors.grey[900]!,
            textStyle: const TextStyle(color: Colors.white),
            inputDecoration: const InputDecoration(
              hintText: 'Search',
              hintStyle: TextStyle(color: Colors.white),
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.white54),
              ),
            ),
          ),
          onSelect: onSelect,
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 15),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              value.isEmpty ? 'Tap to select' : value,
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
