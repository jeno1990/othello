class Coordinate {
  int row;
  int col;

  Coordinate({required this.row, required this.col});
}
