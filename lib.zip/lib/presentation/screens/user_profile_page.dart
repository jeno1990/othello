import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:country_picker/country_picker.dart';

class UserProfilePage extends StatefulWidget {
  const UserProfilePage({super.key});

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final box = GetStorage();

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  DateTime? selectedBirthDate;
  String selectedGender = 'Male';
  String selectedCountry = 'India';
  bool isEditingPassword = false;

  @override
  void initState() {
    super.initState();
    usernameController.text = box.read('username') ?? '';
    emailController.text = box.read('email') ?? '';
    passwordController.text = box.read('password') ?? '';
    cityController.text = box.read('city') ?? '';
    selectedGender = box.read('gender') ?? 'Male';
    selectedCountry = box.read('country') ?? 'India';
    final birth = box.read('birthdate');
    if (birth != null) selectedBirthDate = DateTime.parse(birth);
  }

  void _selectBirthDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedBirthDate ?? DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() => selectedBirthDate = picked);
    }
  }

  void _selectCountry() {
    showCountryPicker(
      context: context,
      showPhoneCode: false,
      onSelect: (Country country) {
        setState(() => selectedCountry = country.name);
      },
    );
  }

  void _saveProfile() {
    if (_formKey.currentState!.validate()) {
      box.write('username', usernameController.text);
      box.write('email', emailController.text);
      box.write('password', passwordController.text);
      box.write('city', cityController.text);
      box.write('gender', selectedGender);
      box.write('country', selectedCountry);
      if (selectedBirthDate != null) {
        box.write('birthdate', selectedBirthDate!.toIso8601String());
      }
      Get.snackbar('Success', 'Profile saved successfully',
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  void _enablePasswordEdit() {
    setState(() => isEditingPassword = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('User Profile', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: const Color(0xFF1E1E1E),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white12,
                child: Icon(Icons.person, size: 50, color: Colors.white),
              ),
              const SizedBox(height: 30),

              _buildTextField("Username", usernameController),
              const SizedBox(height: 15),

              _buildTextField("Email", emailController,
                  keyboardType: TextInputType.emailAddress),
              const SizedBox(height: 15),

              isEditingPassword
                  ? _buildTextField("New Password", passwordController, obscure: true)
                  : ListTile(
                      tileColor: Colors.grey[850],
                      title: const Text('Password', style: TextStyle(color: Colors.white70)),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit, color: Colors.white),
                        onPressed: _enablePasswordEdit,
                      ),
                    ),
              const SizedBox(height: 15),

              _buildTextField("City", cityController),
              const SizedBox(height: 15),

              ListTile(
                tileColor: Colors.grey[850],
                title: const Text('Gender', style: TextStyle(color: Colors.white70)),
                trailing: DropdownButton<String>(
                  value: selectedGender,
                  dropdownColor: Colors.grey[850],
                  style: const TextStyle(color: Colors.white),
                  items: ['Male', 'Female', 'Other']
                      .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                      .toList(),
                  onChanged: (val) => setState(() => selectedGender = val!),
                ),
              ),
              const SizedBox(height: 15),

              ListTile(
                tileColor: Colors.grey[850],
                title: const Text('Birthdate', style: TextStyle(color: Colors.white70)),
                trailing: TextButton(
                  onPressed: _selectBirthDate,
                  child: Text(
                    selectedBirthDate == null
                        ? 'Select Date'
                        : DateFormat('yyyy-MM-dd').format(selectedBirthDate!),
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 15),

              ListTile(
                tileColor: Colors.grey[850],
                title: const Text('Country', style: TextStyle(color: Colors.white70)),
                trailing: TextButton(
                  onPressed: _selectCountry,
                  child: Text(selectedCountry, style: const TextStyle(color: Colors.white)),
                ),
              ),
              const SizedBox(height: 30),

              ElevatedButton(
                onPressed: _saveProfile,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  backgroundColor: Colors.greenAccent[400],
                ),
                child: const Text('Save Profile', style: TextStyle(fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {bool obscure = false,
      TextInputType keyboardType = TextInputType.text}) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        filled: true,
        fillColor: Colors.grey[850],
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}
