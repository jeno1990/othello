import 'dart:ui';

const double BLOCK_SIZE = 45;
const double borderRadiusWide = 6;
const double borderRadiusNarrow = 1;
const int ITEM_EMPTY = 0;
const int ITEM_WHITE = 1;
const int ITEM_BLACK = 2;
const primaryColor = Color(0xff008A60);
