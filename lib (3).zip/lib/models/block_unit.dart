class BlockUnit{
  int value;

  BlockUnit({this.value = 0});

}